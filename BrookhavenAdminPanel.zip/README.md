# Brookhaven Style Admin Panel for Roblox

This is a complete Admin Panel system for Roblox, inspired by Brookhaven. It includes a password-protected login interface and server-side command handling with UI buttons for admin actions.

---

## 🧱 Features

- 🔐 Password login system
- 🚔 Jail player
- 🔓 Free player
- ❌ Kick player
- 🔇 Mute player (toggle)
- 🕊️ Fly/Unfly player (anchored toggle)

---

## 📁 Folder Structure

```
BrookhavenAdminPanel/
│
├── StarterGui/
│   └── AdminUI/
│       └── AdminPanel_LocalScript.lua
│
├── ReplicatedStorage/
│   └── AdminCommand_RemoteEvent.txt
│
├── ServerScriptService/
│   └── AdminCommand_Handler.lua
│
└── Workspace/
    └── JailPosition_Info.txt
```

---

## 🛠️ Setup Instructions (Roblox Studio)

1. **Create GUI Elements** under `StarterGui > ScreenGui` named `AdminUI`
   - `LoginFrame` (with: `PasswordBox`, `EnterButton`, `ErrorLabel`)
   - `CommandPanel` (initially invisible; with: `PlayerNameBox`, `JailButton`, `FreeButton`, `KickButton`, `MuteButton`, `FlyButton`)

2. **Add RemoteEvent**
   - Go to `ReplicatedStorage`
   - Create a `RemoteEvent` and name it **AdminCommand**

3. **Add a Jail Position**
   - In `Workspace`, add a `Part`
   - Name it **JailPosition**
   - Set its position where jailed players should appear

4. **Insert Scripts**
   - Place `AdminPanel_LocalScript.lua` into `StarterGui > AdminUI`
   - Place `AdminCommand_Handler.lua` into `ServerScriptService`

5. **Customize**
   - Change the password in `AdminPanel_LocalScript.lua` (`correctPassword = "admin123"`)

---

## ✅ How it Works

- Player enters a password. If correct, they see the admin command panel.
- Admin selects a player and clicks an action.
- The command is sent securely to the server via `RemoteEvent`.

---

## 🔐 Important Notes

- Make sure `RemoteEvent` and `JailPosition` are created exactly as described.
- This system is intended for your **own game**, not usable in public games like Brookhaven RP.

---

Created by [ChatGPT for Roblox Devs]
