-- LocalScript (StarterGui > AdminUI)
local ui = script.Parent
local loginFrame = ui:WaitForChild("LoginFrame")
local passwordBox = loginFrame:WaitForChild("PasswordBox")
local enterButton = loginFrame:WaitForChild("EnterButton")
local errorLabel = loginFrame:WaitForChild("ErrorLabel")

local panel = ui:WaitForChild("CommandPanel")
local nameBox = panel:WaitForChild("PlayerNameBox")
local jailBtn = panel:WaitForChild("JailButton")
local freeBtn = panel:WaitForChild("FreeButton")
local kickBtn = panel:WaitForChild("KickButton")
local muteBtn = panel:WaitForChild("MuteButton")
local flyBtn = panel:WaitForChild("FlyButton")

local correctPassword = "admin123" -- Cambia tu contraseña aquí

enterButton.MouseButton1Click:Connect(function()
    if passwordBox.Text == correctPassword then
        loginFrame.Visible = false
        panel.Visible = true
    else
        errorLabel.Text = "Contraseña incorrecta"
        errorLabel.Visible = true
    end
end)

local function sendCommand(command)
    local target = nameBox.Text
    if target ~= "" then
        game.ReplicatedStorage:WaitForChild("AdminCommand"):FireServer(command, target)
    end
end

jailBtn.MouseButton1Click:Connect(function() sendCommand("Jail") end)
freeBtn.MouseButton1Click:Connect(function() sendCommand("Free") end)
kickBtn.MouseButton1Click:Connect(function() sendCommand("Kick") end)
muteBtn.MouseButton1Click:Connect(function() sendCommand("Mute") end)
flyBtn.MouseButton1Click:Connect(function() sendCommand("Fly") end)
