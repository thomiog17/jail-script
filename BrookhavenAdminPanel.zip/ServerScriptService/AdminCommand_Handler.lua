-- Script del servidor (ServerScriptService)
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Players = game:GetService("Players")

local adminCommand = ReplicatedStorage:WaitForChild("AdminCommand")
local jailPosition = workspace:WaitForChild("JailPosition") -- Un Part

local mutedPlayers = {}
local flyingPlayers = {}

adminCommand.OnServerEvent:Connect(function(sender, command, targetName)
    for _, player in pairs(Players:GetPlayers()) do
        if player.Name:lower():sub(1, #targetName) == targetName:lower() then
            local char = player.Character
            if not char then return end

            if command == "Jail" and char:FindFirstChild("HumanoidRootPart") then
                char:MoveTo(jailPosition.Position)

            elseif command == "Free" then
                char:MoveTo(Vector3.new(0, 5, 0))

            elseif command == "Kick" then
                player:Kick("Fuiste expulsado por un administrador.")

            elseif command == "Mute" then
                mutedPlayers[player.UserId] = true

            elseif command == "Fly" then
                local hrp = char:FindFirstChild("HumanoidRootPart")
                if hrp then
                    hrp.Anchored = not flyingPlayers[player.UserId]
                    flyingPlayers[player.UserId] = not flyingPlayers[player.UserId]
                end
            end
        end
    end
end)
